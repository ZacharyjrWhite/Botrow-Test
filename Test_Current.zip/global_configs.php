<?php 

return array(
     'dbHost' => "localhost",
     'dbUser' => "horseshoe2",
     'dbPass' => "Molson25!!",
     'dbDatabase' => "horseshoe2",
     'pwSalt' => 'DZL04JpMmkq1vmxLXv62Jw==9h38++rTL0K0I3PioWWB2A'
 )

//return array(
//    'dbHost' => "localhost",
//    'dbUser' => "root",
//    'dbPass' => "",
//    'dbDatabase' => "horseshoe2",
//    'pwSalt' => 'DZL04JpMmkq1vmxLXv62Jw==9h38++rTL0K0I3PioWWB2A'
//)

?>